## 使用方法
解压附件，替换pc-chat/proto_addon目录下的对应的marswrapper.xxx.node文件

## 功能库参数
HOST:chat.tongfudun.com
PORT:80
